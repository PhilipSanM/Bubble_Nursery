# CDT-Templates/Templates/Analisis

Plantilla para documentar el Análisis de Requerimeintos de proyectos pequeños.

Diseñada para los estudiantes de [ESCOM](http://www.escom.ipn.mx/), pero puede ser aprobechada por cualquier interesado en documentar sus requerimientos utilizando LaTeX como herramienta.

Todos los archivos .tex conforman el ejemplo a seguir para ver el uso de los comandos.

Para compilar el ejemplo se debe compilar el archivo ejemplo.tex